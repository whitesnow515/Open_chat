export const StoreType = {
  PINECONE: 'pinecone',
  QDRANT: 'qdrant',
};
export interface StoreOptions {
  namespace?: string;
}
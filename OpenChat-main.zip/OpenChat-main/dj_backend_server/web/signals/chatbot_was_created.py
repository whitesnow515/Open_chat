from django.dispatch import Signal

# Define a custom Django signal
chatbot_was_created = Signal()
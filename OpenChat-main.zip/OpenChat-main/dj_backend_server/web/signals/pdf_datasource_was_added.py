from django.dispatch import Signal
# from web.listeners.ingest_pdf_data_source import IngestPdfDataSource


# bot_id, pdf_data_source_id
pdf_data_source_added = Signal()
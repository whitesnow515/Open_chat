from django.dispatch import Signal

# sender, chatbot_id, website_data_source_id

website_data_source_crawling_completed = Signal()
from django.dispatch import Signal

# Define a custom Django signal
codebase_data_source_added = Signal()
from enum import Enum

class ChatBotDefaults(Enum):
    NAME = "My First Chatbot"
from enum import Enum

class StoreType(Enum):
  PINECONE = 'PINECONE'
  QDRANT = 'QDRANT'
